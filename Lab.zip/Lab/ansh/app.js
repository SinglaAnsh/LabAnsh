// Import required packages
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Book = require('./models/Book'); // Ensure this path is correct based on your folder structure

// Load environment variables from .env file
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB');
    // Call the paginationAndSorting function for page 1 and page 2 after connecting successfully
    paginationAndSorting(1); // Page 1
    paginationAndSorting(2); // Page 2
  })
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Function to retrieve books with pagination and sorting
const paginationAndSorting = async (page) => {
  const booksPerPage = 2; // Return 2 books per page
  
  try {
    // Use .sort() for sorting by publishedDate in descending order
    // Use .skip() and .limit() to implement pagination
    const books = await Book.find()
      .sort({ publishedDate: -1 }) // Sort by publishedDate in descending order
      .skip((page - 1) * booksPerPage) // Skip books based on the page number
      .limit(booksPerPage); // Limit the number of books per page

    // Output the results for the given page
    console.log(`\nBooks for Page ${page}:\n`);
    
    books.forEach((book, index) => {
      console.log(`Book ${index + 1}:`);
      console.log(`Title: ${book.title}`);
      console.log(`Author: ${book.author}`);
      console.log(`Pages: ${book.pages}`);
      console.log(`Published Date: ${book.publishedDate.toDateString()}`);
      console.log(`Genres: ${book.genres.join(', ')}`);
      console.log('\n--------------------\n'); // Space between books
    });

  } catch (error) {
    console.error('Error retrieving paginated books:', error);
  }
};
